package com.example.untitled3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
